import 'package:get/get.dart';
import 'package:todo_firebase/models/user.dart';


class UserController extends GetxController {
   late final Rx<UserModel> _userModel = UserModel().obs; //

  UserModel get user {
    return _userModel.value;
  }

  set user(UserModel value) {
    _userModel.value = value;
  }

  void clear() {
    _userModel.value = UserModel();
  }
}
