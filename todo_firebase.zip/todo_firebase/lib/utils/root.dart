import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:todo_firebase/controllers/authController.dart';
import 'package:todo_firebase/controllers/userController.dart';
import 'package:todo_firebase/screens/home.dart';
import 'package:todo_firebase/screens/login.dart';


class Root extends GetWidget<AuthController> {
  const Root({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetX(
      initState: (_) async {
        Get.put<UserController>(UserController());
      },
      builder: (_) {
   
        if (Get.find<AuthController>().user!.uid != null) {
          return Home();
        } else {
          return Login();
        }
      },
    );
  }
}
